"use strict";

/*
  LOWFATHOM — Session 8D PWA update hardening
  v0.088.7 keeps the known-good Dice Box 1.1.3 runtime offline, fixes native d100 result reading, and suppresses specular highlights for the matte Fathom Obsidian theme.
  Bump CACHE_NAME whenever the shipped app shell changes.
*/
const CACHE_NAME = "lowfathom-v0.088.7";

const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./assets/fathom-die/obsidian/theme.config.json",
  "./assets/fathom-die/obsidian/diffuse-light.png",
  "./assets/fathom-die/obsidian/diffuse-dark.png",
  "./assets/fathom-die/obsidian/specular-black.jpg"
];

// Dice Box currently runs from this exact, known-good 1.1.3 CDN build.
// The service worker saves copies of these files so the die can work offline
// after the app has had an online opportunity to warm the cache.
const DICEBOX_CDN_PREFIX = "https://unpkg.com/@3d-dice/dice-box@1.1.3/dist/";
const DICEBOX_OFFLINE_FILES = [
  `${DICEBOX_CDN_PREFIX}dice-box.es.min.js`,
  `${DICEBOX_CDN_PREFIX}world.onscreen.min.js`,
  `${DICEBOX_CDN_PREFIX}world.none.min.js`,
  `${DICEBOX_CDN_PREFIX}Dice.min.js`,
  `${DICEBOX_CDN_PREFIX}assets/ammo/ammo.wasm.wasm`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/theme.config.json`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/default.json`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/diffuse-dark.png`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/diffuse-light.png`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/normal.png`,
  `${DICEBOX_CDN_PREFIX}assets/themes/default/specular.jpg`
];

async function cacheResponse(cache, request, response) {
  if (response && (response.ok || response.type === "opaque")) {
    await cache.put(request, response.clone());
  }
  return response;
}

async function warmDiceBoxCache() {
  const cache = await caches.open(CACHE_NAME);
  // Never prevent a Fathom update because one optional CDN file was temporarily
  // unavailable. Any missing file will also be cached automatically when Dice Box
  // requests it during a later online run.
  await Promise.allSettled(
    DICEBOX_OFFLINE_FILES.map(async url => {
      const request = new Request(url, { mode: "cors", cache: "no-store" });
      const response = await fetch(request);
      await cacheResponse(cache, request, response);
    })
  );
}

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(async cache => {
        // Bypass the browser HTTP cache while installing a new app shell so a
        // newly-versioned worker cannot seed itself with an older index.html.
        const requests = APP_SHELL.map(path =>
          new Request(new URL(path, self.location).href, { cache: "reload" })
        );
        await cache.addAll(requests);
        await warmDiceBoxCache();
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(names =>
        Promise.all(
          names
            .filter(name => name.startsWith("lowfathom-") && name !== CACHE_NAME)
            .map(name => caches.delete(name))
        )
      )
      .then(() => self.clients.claim())
  );
});

function fetchFresh(request) {
  const url = new URL(request.url);
  return url.origin === self.location.origin
    ? fetch(request, { cache: "no-store" })
    : fetch(request);
}

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // Dice Box is version-pinned. Prefer our saved copy so its behavior does not
  // change underneath the game and so the same physical die can load offline.
  if (url.href.startsWith(DICEBOX_CDN_PREFIX)) {
    event.respondWith(
      caches.match(request, { ignoreSearch: true })
        .then(cached => {
          if (cached) return cached;
          return fetch(request).then(async response => {
            const cache = await caches.open(CACHE_NAME);
            await cacheResponse(cache, request, response);
            return response;
          });
        })
    );
    return;
  }

  // Navigation requests get the newest index while online, then fall back to
  // the cached app shell when the network is unavailable.
  if (request.mode === "navigate") {
    event.respondWith(
      fetchFresh(request)
        .then(response => {
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put("./index.html", copy));
          }
          return response;
        })
        .catch(() =>
          caches.match("./index.html")
            .then(cached => cached || caches.match("./"))
        )
    );
    return;
  }

  // For ordinary assets use network-first while developing so updates appear
  // promptly, with cache fallback for offline use.
  event.respondWith(
    fetchFresh(request)
      .then(response => {
        if (response && (response.ok || response.type === "opaque")) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        }
        return response;
      })
      .catch(() => caches.match(request, { ignoreSearch: true }))
  );
});
